package streams;

/* NOTHING TO SEE HERE */

public class Main {
    public static void main(String[] args) {
    }

}
