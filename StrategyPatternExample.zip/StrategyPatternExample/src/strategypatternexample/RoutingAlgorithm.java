package strategypatternexample;

// The strategies for the routing algorithms

// Each contains a function to calculate a route with a given map, starting point and end point
public interface RoutingAlgorithm {
    public Route calcRoute(Map map, String start, String end);
}

// This strategy takes all roads into account
class NormalRoute implements RoutingAlgorithm {
    @Override
    public Route calcRoute(Map map, String start, String end) {
        return map.calcShortestFromTo(start, end);
    }
}

// This strategy only takes car roads into account
class CarRoute implements RoutingAlgorithm {
    @Override
    public Route calcRoute(Map map, String start, String end) {
        Map newMap = map.onlyRoadsWith("Car");
        return newMap.calcShortestFromTo(start, end);
    }
}

class RouteViaD implements RoutingAlgorithm {
    @Override
    public Route calcRoute(Map map, String start, String end) {
        Route route1 = map.calcShortestFromTo(start, "D");
        Route route2 = map.calcShortestFromTo("D", end);
        route1.addRoute(route2);
        return route1;
    }
}
