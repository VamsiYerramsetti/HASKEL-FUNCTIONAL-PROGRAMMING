package strategypatternexample;

import java.util.LinkedList;

// The Class that represents routes
// Not relevant for the students
public class Route {
    private LinkedList<String> nodes;
    private int length;
    
    public Route (LinkedList <String> nodes, int length) {
        this.nodes = nodes;
        this.length = length;
    }
    
    public void updateWithNodeAndLength(String node, int length) {
        nodes.offerFirst(node);
        this.length += length;
    }

    public void addRoute(Route route){
        LinkedList<String> additroutes = route.getNodes();
        additroutes.remove();
        this.nodes.addAll(additroutes);
        this.length += route.getLength();
    }
    
    public int getLength() {
        return length;
    }

    public LinkedList<String> getNodes() {
        return nodes;
    }
    
    

    @Override
    public String toString() {
        return "Route{" + "nodes=" + nodes + ", length=" + length + '}';
    }
    
}
