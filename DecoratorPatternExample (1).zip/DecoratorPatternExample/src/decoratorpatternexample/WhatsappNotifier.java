package decoratorpatternexample;

// The Decorator for the Whatsapp Notifier
public class WhatsappNotifier extends BaseNotifierDecorator {
    // Super simply calls the Constructor of the parent class
    // In this case BaseNotifierDecorator, so it simply sets the base
    public WhatsappNotifier (Notifier n) {
        super(n);
    }
    
    // This notifyUser notifies a user via Whatsapp
    @Override
    public void notifyUser() {
        super.notifyUser();
        System.out.println("Notifying via Whatsapp");
        // Notify via Whatsapp
    }
}
