package visitorpatternexample;

import java.util.Arrays;
import java.util.List;

public class VisitorPatternExample {

    public static void main(String[] args) {
        // Creating the objects
        Book book1 = new Book("Alice in Wonderland", 15, 3);
        Book book2 = new Book("Bob in Wonderland", 10, 2);
        Book book3 = new Book("Eve in Wonderland", 18, 5);
        DVD dvd1 = new DVD("The Beatles", 5);
        DVD dvd2 = new DVD("ABBA", 7);
        List<Item> items = Arrays.asList(book1, book2, book3, dvd1, dvd2);
        Giftbox giftbox1 = new Giftbox("giftbox", items);
        
        // A simple example to illustrate the inner working of the accept function
        Visitor v1 = new CountVisitor();
        book1.accept(v1);
        System.out.println(v1);
        
        // As there are 3 books and 2 DVDs in the giftbox, that will be the result
        Visitor v2 = new CountVisitor();
        giftbox1.accept(v2);
        System.out.println(v2);
        
        // As the books have a total weight of 10,
        // the DVDs both have a standard weight of 1.
        // and the box has an additional weight of 2,
        // the total weight will be 14
        Visitor v3 = new WeightVisitor();
        giftbox1.accept(v3);
        System.out.println(v3);
    }
    
}
