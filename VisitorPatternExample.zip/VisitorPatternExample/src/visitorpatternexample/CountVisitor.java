package visitorpatternexample;

public class CountVisitor implements Visitor {
    // This Visitor counts the number of books and dvds
    private int books = 0;
    private int dvds = 0;
    
    // When a book is inspected, the number of books should increase
    @Override
    public void visitBook(Book b) {
        books += 1;
    }
    
    // When a DVD is inspected, the number of DVDs should increase
    @Override
    public void visitDVD(DVD d) {
        dvds += 1;
    }
    
    // When a giftbox is inspected, this visitor is called on all items with the accept functions
    @Override 
    public void visitGiftbox(Giftbox g) {
        for(Item i : g.getItems()) {
            i.accept(this);
        }
    }

    @Override
    public String toString() {
        return "CountVisitor{" + "books=" + books + ", dvds=" + dvds + '}';
    }
    
    
}
