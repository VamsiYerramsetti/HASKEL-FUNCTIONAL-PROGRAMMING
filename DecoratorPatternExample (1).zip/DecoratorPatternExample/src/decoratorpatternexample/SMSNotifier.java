package decoratorpatternexample;

// The Decorator for the SMS Notifier
public class SMSNotifier extends BaseNotifierDecorator {
    // Super simply calls the Constructor of the parent class
    // In this case BaseNotifierDecorator, so it simply sets the base
    public SMSNotifier (Notifier n) {
        super(n);
    }
    
    // This notifyUser notifies a user via SMS
    @Override
    public void notifyUser() {
        super.notifyUser();
        System.out.println("Notifying via SMS");
        // Notify via SMS
    }
}
