package decoratorpatternexample;

// The Base Decorator for the program
public class BaseNotifierDecorator implements Notifier {
    private Notifier base;
    
    // Constructor simply sets the attribute base Notifier
    public BaseNotifierDecorator(Notifier n) {
        this.base = n;
    }
    
    // NotifyUser simply calls the notifyUser function on the stored base
    @Override
    public void notifyUser() {
        base.notifyUser();
    }
}
