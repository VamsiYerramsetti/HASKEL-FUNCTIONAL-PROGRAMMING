package decoratorpatternexample;

// The Concrete Email Notifier
// Note that is does not contain another Notifier inside it, is this is the wrappee and not a wrapper
public class EmailNotifier implements Notifier {
    // This notifyUser gives an email notifier
    @Override
    public void notifyUser() {
        System.out.println("Notifying via mail");
        // Notify via mail
    }
}
