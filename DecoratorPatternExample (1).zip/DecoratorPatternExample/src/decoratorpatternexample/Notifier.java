package decoratorpatternexample;

// The Notifier interface
public interface Notifier {
    public void notifyUser();
}
