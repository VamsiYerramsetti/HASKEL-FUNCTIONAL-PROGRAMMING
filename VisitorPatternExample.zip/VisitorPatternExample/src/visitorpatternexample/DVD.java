package visitorpatternexample;

public class DVD extends Item {
    
    public DVD (String name, int price) {
        super(name,price);
    }
    
    // The accept function simply refers to the corresponding visit function in the Visitor
    @Override
    public void accept(Visitor v) {
        v.visitDVD(this);
    }
        
}
