package strategypatternexample;

import java.util.Arrays;

// The Class that represents the Edges on the Map
// Not relevant for the students
public class Edge {
    private int length;
    private String[] vehicles;
    private String point1;
    private String point2;
    
    public Edge(int length, String[] vehicles, String point1, String point2) {
        this.length = length;
        this.vehicles = vehicles;
        this.point1 = point1;
        this.point2 = point2;
    }
    
    public String getPoints(){
        return (point1 + " " + point2);
    }

    public int getLength() {
        return length;
    }

    public String[] getVehicles() {
        return vehicles;
    }

    @Override
    public String toString() {
        return "Edge{" + "length=" + length + ", vehicles=" + Arrays.toString(vehicles) + ", point1=" + point1 + ", point2=" + point2 + '}';
    }
    
   
}
