package decoratorpatternexample;

// The Decorator for the Instagram Notifier
public class InstagramNotifier extends BaseNotifierDecorator {
    // Super simply calls the Constructor of the parent class
    // In this case BaseNotifierDecorator, so it simply sets the base
    public InstagramNotifier (Notifier n) {
        super(n);
    }
    
    // This notifyUser notifies a user via Instagram
    @Override
    public void notifyUser() {
        super.notifyUser();
        System.out.println("Notifying via Instagram");
        // Notify via Instagram
    }
}
