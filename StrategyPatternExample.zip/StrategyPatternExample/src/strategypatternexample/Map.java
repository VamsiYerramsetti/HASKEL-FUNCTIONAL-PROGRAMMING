package strategypatternexample;

import java.util.Arrays;
import java.util.LinkedList;

// The Class that represents a map with some routing algorithms
// Not relevant for the students
public class Map {
    private LinkedList<Edge> roads;
    
    public Map(LinkedList<Edge> roads) {
        this.roads = roads;
    }
    
    private Route calcShortestFromToRec(String start, String end, int iteration) {
        if (iteration >= 4)
            return null;
        if (start.equals(end)) {
            LinkedList<String> list = new LinkedList<>();
            list.add(start);
            return (new Route(list, 0));
        }
        iteration+=1;
        LinkedList<Route> routes = new LinkedList<>();
        if (findEdgeFromTo(start, "A") != null && !"A".equals(start)) {
            Route imroute = calcShortestFromToRec("A", end, iteration);
            if (imroute != null) {
                imroute.updateWithNodeAndLength(start, findEdgeFromTo(start, "A").getLength());
                routes.add(imroute);
            }
        }
        if (findEdgeFromTo(start, "B") != null && !"B".equals(start)) {
            Route imroute = calcShortestFromToRec("B", end, iteration);
            if (imroute != null) {
                imroute.updateWithNodeAndLength(start, findEdgeFromTo(start, "B").getLength());
                routes.add(imroute);
            }
        }
        if (findEdgeFromTo(start, "C") != null && !"C".equals(start)) {
            Route imroute = calcShortestFromToRec("C", end, iteration);
            if (imroute != null) {
                imroute.updateWithNodeAndLength(start, findEdgeFromTo(start, "C").getLength());
                routes.add(imroute);
            }
        }
        if (findEdgeFromTo(start, "D") != null && !"D".equals(start)) {
            Route imroute = calcShortestFromToRec("D", end, iteration);
            if (imroute != null) {
                imroute.updateWithNodeAndLength(start, findEdgeFromTo(start, "D").getLength());
                routes.add(imroute);
            }
        }
        return getBestRoute(routes);
    }
    
    private Route getBestRoute(LinkedList<Route> routes) {
        if (routes.isEmpty())
            return null;
        Route bestRoute = routes.get(0);
        for (int i = 1; i < routes.size(); i++) {
            if(routes.get(i).getLength() < bestRoute.getLength())
                bestRoute = routes.get(i);
        }
        return bestRoute;
    }
    
    public Route calcShortestFromTo(String start, String end) {
        return calcShortestFromToRec(start, end, 0);
    }
    
    private Edge findEdgeFromTo(String start, String end) {
        for(Edge e: roads) {
            String points = e.getPoints();
            if (points.equals(start + " " + end) || points.equals(end + " " + start))
                return e;
        }
        return null;
    }
    
    public Map onlyRoadsWith(String vehicle) {
        LinkedList<Edge> result = new LinkedList<>();
        for(Edge e : roads) {
            if(Arrays.asList(e.getVehicles()).contains(vehicle))
                result.add(e);
        }
        return new Map(result);
    }

    @Override
    public String toString() {
        return "Map{" + "roads=" + roads + '}';
    }
    
    
}


