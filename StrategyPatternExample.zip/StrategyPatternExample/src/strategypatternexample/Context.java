package strategypatternexample;

import java.util.Arrays;
import java.util.LinkedList;

public class Context {
    // The used Strategy
    private RoutingAlgorithm ra;
    // The used map for the strategy
    public final Map roadmap = new Map(new LinkedList<>(Arrays.asList(
        new Edge(4, new String[] {"Car","Walk"}, "A", "B"),
        new Edge(8, new String[] {"Car","Walk"}, "B", "C"),
        new Edge(7, new String[] {"Car","Walk"}, "C", "D"),
        new Edge(10, new String[] {"Car","Walk"}, "D", "A"),
        new Edge(3, new String[] {"Walk"}, "A", "C"),
        new Edge(2, new String[] {"Walk"}, "B", "D"))));
    
    // Returns the shortest route on the attribute roadmap with the given start and end point
    public Route returnRoute(String startpoint, String endpoint) {
        return ra.calcRoute(roadmap, startpoint, endpoint);
    }

    public void setRa(RoutingAlgorithm ra) {
        this.ra = ra;
    }
    
    
}
