package visitorpatternexample;

public class Book extends Item {
     // Books do have an additional weight as an attribute
     private int weight;
     
     public Book(String name, int price, int weight) {
         super(name, price);
         this.weight = weight;
     }
     
     // The accept function simply refers to the corresponding visit function in the Visitor
     @Override
     public void accept(Visitor v){
         v.visitBook(this);
     }

    public int getWeight() {
        return weight;
    }

}
