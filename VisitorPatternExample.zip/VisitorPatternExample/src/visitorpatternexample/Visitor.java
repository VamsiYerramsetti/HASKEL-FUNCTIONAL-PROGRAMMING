package visitorpatternexample;

public interface Visitor {
    // Contain a specific visit function for each object
    public void visitBook(Book b);
    public void visitDVD(DVD d);
    public void visitGiftbox(Giftbox g);
    
}
