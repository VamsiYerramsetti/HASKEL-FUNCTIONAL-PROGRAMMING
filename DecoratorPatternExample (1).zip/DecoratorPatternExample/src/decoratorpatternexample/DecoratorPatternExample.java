package decoratorpatternexample;

public class DecoratorPatternExample {
    public static void main(String[] args) {
        System.out.println("Notifier 1:");
        // Only the basic Notifier
        Notifier n1 = new EmailNotifier();
        n1.notifyUser();
        System.out.println("Notifier 2:");
        // A basic Notifier with Whatsapp and Instagram as well
        Notifier n2 = new WhatsappNotifier(new InstagramNotifier(new EmailNotifier()));
        n2.notifyUser();
    }
    
}
