package visitorpatternexample;

import java.util.List;

public class Giftbox extends Item {
    // Giftboxes contain a list of items
    private List<Item> items;
    
    public Giftbox (String name, List<Item> items) {
        // super calls the Object above the current object, Item in this case
        // So the Item constructor is called with the given name and the calculated price
        super(name, getTotalPrice(items));
        this.items = items;
    }
    
    // Function to calculate the total weight of a list of items
    private static int getTotalPrice(List<Item> items) {
        int result = 0;
        for(Item i : items) {
            result += i.getPrice();
        }
        return result;
    }
    
    // The accept function simply refers to the corresponding visit function in the Visitor
    @Override
    public void accept(Visitor v) {
        v.visitGiftbox(this);
    }

    public List<Item> getItems() {
        return items;
    }
    
}
