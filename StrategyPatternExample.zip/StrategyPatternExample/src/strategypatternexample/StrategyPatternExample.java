package strategypatternexample;

public class StrategyPatternExample {

    public static void main(String[] args) {
        Context context = new Context();
        // The normal routing algorithm is used
        context.setRa(new NormalRoute());
        System.out.println(context.returnRoute("A","D"));
        // Only car routes can be used
        context.setRa(new CarRoute());
        System.out.println(context.returnRoute("A","D"));
        System.out.println(context.returnRoute("D","B"));
        // All routes can be used, but the route should go via D
        context.setRa(new RouteViaD());
        System.out.println(context.returnRoute("A","C"));
        System.out.println(context.returnRoute("A","A"));
    }
    
}
