package visitorpatternexample;

public interface Visitable {
    // Only contians the accept function
    public void accept(Visitor v);
}
