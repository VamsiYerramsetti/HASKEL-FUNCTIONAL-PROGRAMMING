package visitorpatternexample;

public class WeightVisitor implements Visitor {
    // This Visitor calculates the total weight of items
    int weight = 0;
    
    // When a book inspected, its weight attribute is added
    @Override
    public void visitBook(Book b) {
        weight += b.getWeight();
    }
    
    // When a DVD is inspected, its standard weight of 1 is added
    @Override
    public void visitDVD(DVD d) {
        weight += 1;
    }
    
    // When a giftbox is inspected, an additional weight of 2 is added to the weights of all items
    // These are inspected with the accept function.
    @Override
    public void visitGiftbox(Giftbox g) {
        weight += 2; // Weight of the box
        for(Item i : g.getItems()) {
            i.accept(this);
        }
    }

    @Override
    public String toString() {
        return "WeightVisitor{" + "weight=" + weight + '}';
    }
    
    
}
